require("dotenv").config();
const {
  WAConnection,
  MessageType,
  ReconnectMode,
  Presence,
  Mimetype,
} = require("@adiwajshing/baileys");
const moment = require("moment-timezone");
client = new WAConnection();

module.exports = function () {};
